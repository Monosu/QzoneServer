CREATE PROCEDURE `UserLogin`(`username` VARCHAR(100), `userpassWord` VARCHAR(100))
  BEGIN
	set errcount = 0;
	set errMsg = '';
	set @userid = 0;
	set @userpsd = '';
	set userid = 0;
	select @userid:=id,@userpsd:=password from userinfo where loginName = username; 
	if @userid > 0 then
	begin
		if userpassWord = @userpsd then
		begin
			set errcount=0;
			set errMsg='';
			set userid=@userid;
		end;
		else
		begin
			set errcount = 2;
			set errMsg = '密码错误';
		end;
		end if;
	end;
	else
	begin
		set errcount = 1;
		set errMsg = '用户名不存在';
	end;
	end if;
    END