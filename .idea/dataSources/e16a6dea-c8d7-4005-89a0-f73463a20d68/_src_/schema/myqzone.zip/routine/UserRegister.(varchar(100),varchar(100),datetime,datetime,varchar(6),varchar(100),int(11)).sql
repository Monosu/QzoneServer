CREATE PROCEDURE `UserRegister`(`username`         VARCHAR(100), `userpsd` VARCHAR(100), `userlasttime` DATETIME,
                                `userregisterTime` DATETIME, `usersex` VARCHAR(6), `usernikename` VARCHAR(100),
                                `userhead`         INT(11))
  BEGIN
	DECLARE errorSum INT DEFAULT 0;
	DECLARE CONTINUE HANDLER FOR SQLWARNING,SQLEXCEPTION SET errorSum = 1 ;
	#初始化输出参数
	set errcount = 0,errmsg='',userid=0;
	#定义变量。存储用户id
	set @uid = 0;
	#启动事务
	start transaction;
	#定义变量并查询用户表有没有存在该条记录
	set @isuser = 0;
	select @isuser:=count(id) from userinfo where LoginName = username;
	#如果用户表不存在该用户名就是可以注册
	if @isuser = 0 then
	begin 
		#把用户信息添加到用户表
		insert into userinfo(LoginName,passWord,lastTime,registerTime,sex,nikeName,userheadimg)values(username,userpsd,userlasttime,userregisterTime,usersex,usernikename,userhead);
		#获取添加后的自增ID
		set @uid = @@IDENTITY;
		#判断自增id是否大于0。小于0代表没有添加成功
		if @uid > 0 then
		begin
			#重定义系统自增ID。每次用完需要在使用都需要重新定义
			set @@IDENTITY = 0;
			set @qzoneid = 0;
			#插入到个人空间表
			insert into userqzone(qzonename,QzoneDescript,userid)values(username,concat(username,'的个人空间'),@uid);
			set @qzoneid = @@IDENTITY;
			#如果返回为0代表添加失败
			if @qzoneid = 0 then
			begin
				SET errcount = 3;
				SET errmsg =' 添加空间表失败';
			end;
			else
			begin
				#重定义变量
				set @typeid = 0;
				SET @@IDENTITY = 0;
				#添加相册分类
				insert into albumstype(typeName,userid,addTime)values(concat(username,'个人相册'),@uid,now());
				set @typeid = @@IDENTITY;
				if @typeid = 0 then
				begin
					SET errcount = 4;
					SET errmsg ='添加相册分类失败';
				end;
				else
				begin
					#如果添加成功则继续添加日志分类
					SET @typeid = 0;
					SET @@IDENTITY = 0;
					insert into journaltype(typename,posttime,userid)values('默认日志',now(),@uid);
					SET @typeid = @@IDENTITY;
					if @typeid = 0 then
					begin
						SET errcount = 5;
						SET errmsg ='添加日志分类失败';
					end;
					end if;
				end;
				end if;
			end;
			end if;
		end;
		else
		begin
			SET errcount = 2;
			SET errmsg =' 添加用户表失败';
		end;
		end if;
	end;
	else
	begin
		set errcount = 1;
		set errmsg ='用户名已存在';
	end;
	end if;
	#判断是否有引发过异常或者添加失败
	if errcount <> 0 or errorSum <> 0 then
	begin
		#如果errorSum>0 代表是插入时引发的异常。否则就是添加失败异常
		if errorSum > 0 then
		begin
			set errcount = 6;
			set errmsg = '系统错误异常';
		end;
		end if;
		set userid = 0;
		#回滚事务
		rollback;
	end;
	else
	begin
		#提交事务
		commit;
		#设置返回值
		set userid = @uid;
	end;
	end if;
	
    END