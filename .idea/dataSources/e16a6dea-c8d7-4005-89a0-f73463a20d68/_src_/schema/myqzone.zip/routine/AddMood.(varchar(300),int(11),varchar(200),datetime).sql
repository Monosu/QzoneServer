CREATE PROCEDURE `AddMood`(`parm_MoodContext` VARCHAR(300), `parm_userid` INT(11), `parm_fid` VARCHAR(200),
                           `parm_postTime`    DATETIME)
  BEGIN
	DECLARE errorSum INT DEFAULT 0;
	DECLARE CONTINUE HANDLER FOR SQLWARNING,SQLEXCEPTION SET errorSum = 1 ;
	#初始化输出参数
	SET errcount = 0,errmsg='',@mid=0,@fmid =0;
	start transaction;
	insert into mood(MoodContext,userid,fid,postTime)values(parm_MoodContext,parm_userid,parm_fid,parm_postTime);
	set @mid = @@identity;
	if @mid > 0 then
	begin
		set @@identity = 0;
		insert into friendmoving(movingtype,movingid,userid,posttime)values(1,@mid,parm_userid,parm_postTime);
		set @fmid = @@identity;
		if @fmid <= 0 then
		begin
			set errcount = 2;
			set errmsg = '添加动态表失败';
		end;
		
		end if;
	end;
	else
	begin
		set errcount = 1;
		set errmsg = '添加说说表失败';
	end;
	end if;
	
	if errcount <> 0 or errorSum <> 0 THEN
	begin
		if errcount <=0 then
		begin
			set errcount = 3;
			set errmsg = '系统错误';
		end;
		end if;
		rollback;
	end;
	else
	begin
		set errcount = 4;
		set errmsg = '添加成功';
		commit;
	end;
	end if;
    END