CREATE PROCEDURE `AddUserFiles`(`userfilename` VARCHAR(100), `userfilepath` VARCHAR(100), `userfilesize` INT(11),
                                `userfileexp`  VARCHAR(50), `useruploadtime` VARCHAR(100))
  BEGIN
	DECLARE errorSum INT DEFAULT 0;
	DECLARE CONTINUE HANDLER FOR SQLWARNING,SQLEXCEPTION SET errorSum = 1 ;
	set errcount = 0,errmsg = '',fileid = 0;
	insert into userfiles(FileExp,filepath,FileName,FileSize,UploadTime)values(userfileexp,userfilepath,userfilename,userfilesize,useruploadtime);
	set fileid = @@IDENTITY;
	if errorSum > 0 then
	begin
		set errcount = 1;
		set errmsg = '添加失败';
		set fileid = 0;
	end;
	end if;
    END