CREATE PROCEDURE `find_password`(`username` VARCHAR(20), `usernikename` VARCHAR(20), `userpassword` VARCHAR(20))
  BEGIN
	SET errcount=0;
	SET errmsg='';
	SET @userid:=0;
	SET @userid1=0;
	SELECT @userid:=id FROM userinfo WHERE loginname=username ;
	IF @userid>0 THEN
	BEGIN
		SET errcount=0;
		SET errmsg='';
		SELECT @userid1:=id FROM userinfo WHERE nikename=usernikename;
		IF @userid=@userid1 THEN
		BEGIN
			UPDATE userinfo SET PASSWORD=userpassword WHERE id=@userid;
			SET errcount=0;
			SET errmsg='';
			
		END;
		ELSE
		BEGIN
			SET errcount=2;
			SET errmsg='昵称不存在';
		END;
		END IF;
		
	END;
	ELSE
	BEGIN
		SET errcount=1;
		SET errmsg='该用户不存在';
	END;
	END IF;
    END